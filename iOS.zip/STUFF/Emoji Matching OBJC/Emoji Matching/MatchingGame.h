//
//  MatchingGame.h
//  Emoji Matching
//
//  Created by CSSE Department on 7/1/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MatchingGame : NSObject{
}
- (id) initWithNumPairs:(NSInteger) numPairs;
- (BOOL) pressedAtIndex:(NSInteger) index;
- (NSString*) getIcon:(NSInteger) index;
- (NSString*) getState:(NSInteger) index;
- (int) getPrevious;
@property (nonatomic) int numPairs;
@property (nonatomic) int previous;
@property (nonatomic) NSArray* cards;
@property (nonatomic) NSString* cardBack;
@property (nonatomic) NSMutableArray* cardStates;
@end
