//
//  MatchingGame.m
//  Emoji Matching
//
//  Created by CSSE Department on 7/1/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

#import "MatchingGame.h"

@implementation MatchingGame



- (id) initWithNumPairs:(NSInteger) numPairs{
    self = [super init];
    self.numPairs = numPairs;
    self.previous = -1;
    NSArray* allCardBacks = [@"🎆,🎇,🌈,🌅,🌇,🌉,🌃,🌄,⛺,⛲,🚢,🌌,🌋,🗽" componentsSeparatedByString:@","];
    NSArray* allEmojis = [@"🚁,🐴,🐇,🐢,🐱,🐌,🐒,🐞,🐫,🐠,🐬,🐩,🐶,🐰,🐼,⛄,🌸,⛅,🐸,🐳,❄,❤,🐝,🌺,🌼,🌽,🍌,🍎,🍡,🏡,🌻,🍉,🍒,🍦,👠,🐧,👛,🐛,🐘,🐨,😃,🐻,🐹,🐲,🐊,🐙" componentsSeparatedByString:@","];
    NSString* state = @"hidden";
    NSMutableArray* states = [[NSMutableArray alloc] init];

    NSMutableArray* emojis = [[NSMutableArray alloc] init];
    while (emojis.count < numPairs) {
        NSString* symbol = allEmojis[arc4random_uniform(allEmojis.count)];
        //NSLog(@"%@", symbol);
        if (! [emojis containsObject:symbol]) {
            [emojis addObject:symbol];
            [states addObject:state];
            [states addObject:state];
        }
    }
    [emojis addObjectsFromArray:emojis];
    for (int i=0; i<emojis.count; i++) {
        UInt32 j = arc4random_uniform(emojis.count-i)+i;
        [emojis exchangeObjectAtIndex:i withObjectAtIndex:j];
    }
    self.cards=[NSArray arrayWithArray:emojis];
    self.cardBack=allCardBacks[arc4random_uniform(allCardBacks.count-1)];
    self.cardStates=[NSMutableArray arrayWithArray:states];
    [self printGame];
    return self;
}
- (BOOL) pressedAtIndex:(NSInteger) index{
    if (![self isGameOver]) {
        if ([self getState:index] == @"hidden") {
            if ([self getPrevious] == -1) {
                self.previous = index;
                self.cardStates[index] = @"displayed";
                return NO;
            }else{
                if ([self.cards[self.previous] isEqualToString:self.cards[index]]) {
                    self.cardStates[index] = @"";
                    self.cardStates[self.previous] = @"";
                }else{
                    self.cardStates[self.previous] = @"hidden";
                }
                self.previous = -1;
                return YES;
            }
        }else{
            return NO;
        }
    }
    return NO;
}
- (NSString*) getIcon:(NSInteger) index{

    if ([self.cardStates[index] isEqualToString:@"hidden"]) {
        return self.cardBack;
    }else if ([self.cardStates[index] isEqualToString:@"displayed"]){
        return self.cards[index];
    }
    return @"";
    
}
- (NSString*) getState:(NSInteger) index{
    return self.cardStates[index];
}
- (int) getPrevious{
    return self.previous;
}

- (BOOL) isGameOver{
    for (int i=0; i < self.cardStates.count; i++) {
        if (![self.cardStates[i] isEqualToString:@""]) {
            return NO;
        }
    }
    return YES;
}

- (void) printGame{
    NSString* string = @"\n";
    for (int i=0; i<self.numPairs*2; i++) {
        string =[string stringByAppendingString:self.cards[i]];
        if ((i+1) % 4 == 0) {
            string =[string stringByAppendingString:@"\n"];
        }
    }
    NSLog(@"%@", string);
}

@end
