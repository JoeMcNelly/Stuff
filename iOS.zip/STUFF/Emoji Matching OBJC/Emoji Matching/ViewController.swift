//
//  ViewController.swift
//  Emoji Matching
//
//  Created by CSSE Department on 6/22/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func newGame(sender: AnyObject) {
        game = MatchingGame(numPairs: 10)
        update();
    }
    
    var clickable = true
    @IBOutlet var buttons: [UIButton]!
    
    
    
    @IBAction func buttonPressed(sender: AnyObject) {
        
        if clickable{
            let button = sender as! UIButton
            //if game.state[button.tag].rawValue == "hidden"{
            if game.getState(button.tag) == "hidden"{
            var isSecond = game.getPrevious() != -1
            if isSecond{
                //button.setTitle(String(game.emojis[button.tag]), forState: .Normal)
                button.setTitle(String(game.cards[button.tag] as! NSString), forState: .Normal)
                clickable = false
                delay(1.2){
                    self.clickable = true
                    self.updateGame(button.tag)

                }
            }else{
                updateGame(button.tag)
            }
            }}
    }
    func updateGame(index :Int){
        game.pressedAtIndex(index)
        update()
    }
    
    var game = MatchingGame(numPairs: 10)
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        update()
    }

    func delay(delay:Double, closure:()->()) {
        dispatch_after(
            dispatch_time(
                DISPATCH_TIME_NOW,
                Int64(delay * Double(NSEC_PER_SEC))
            ),
            dispatch_get_main_queue(), closure)
    }

    func update(){
        for button in buttons{
            button.setTitle(game.getIcon(button.tag), forState: .Normal)
        }
    }
}

