//
//  File.swift
//  Emoji Matching
//
//  Created by CSSE Department on 6/22/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

import UIKit

extension Array {
    mutating func shuffle() {
        for i in 0..<(count - 1) {
            let j = Int(arc4random_uniform(UInt32(count - i))) + i
            swap(&self[i], &self[j])
        }
    }
}

class MatchingGame:Printable
{
    var description: String
    {
        return "Game is running"
    }
    let allCardBacks = Array("🎆🎇🌈🌅🌇🌉🌃🌄⛺⛲🚢🌌🌋🗽")
    let allEmojiCharacters = Array("🚁🐴🐇🐢🐱🐌🐒🐞🐫🐠🐬🐩🐶🐰🐼⛄🌸⛅🐸🐳❄❤🐝🌺🌼🌽🍌🍎🍡🏡🌻🍉🍒🍦👠🐧👛🐛🐘🐨😃🐻🐹🐲🐊🐙")
    
    enum CardState: String{
    case Gone = "gone"
    case Hidden = "hidden"
    case Displayed = "displayed"
    }
    var cardBack : Character
    var emojis : [Character]
    var state : [CardState]
    var previous = -1
    var gameNotOver = true
    
    init(numPairs: Int)
    {
    cardBack = allCardBacks[Int(arc4random_uniform(UInt32(allCardBacks.count)))]
    emojis = [Character]()
    state = [CardState]()
    while (emojis.count != numPairs)
    {
        var randIndex = Int(arc4random_uniform(UInt32(allEmojiCharacters.count)))
        if !contains(emojis, allEmojiCharacters[randIndex])
        {
            emojis.append(allEmojiCharacters[randIndex])
            state.append(.Hidden)
            state.append(.Hidden)
        }
    }
    emojis = emojis + emojis
    emojis.shuffle()
    printCheatSheet()
    }

    func printCheatSheet()
    {
        var s = ""
        var count = 1
        for emo in emojis
        {
        
            s = s + String(emo)
            if count % 4 == 0
            {
                s = s + "\n"
            }
            count = count + 1
        }
        println(s)
    }
    func pressedAtIndex(index: Int) -> Bool
    {
        if gameNotOver
        {
            if state[index] == .Hidden
            {
                if previous == -1
                {
                        previous = index
                        state[index] = .Displayed
                        return false
                }else{
                
                    if emojis[previous] == emojis[index]{
                        state[index] = .Gone
                        state[previous] = .Gone
                        //emojis[previous] = Character("")
                        //emojis[index] = Character("")
                        checkIsGameWon()
                    }else{
                        state[previous] = .Hidden
                    }
                    previous = -1
                    return true
                }
            }
            else
            {
                return false
            }
        }
    return false
    }
    func checkIsGameWon(){
        for cState in state{
            if cState != .Gone{
                return
            }
        }
        gameNotOver = false
    }
    
    func getIcon(index: Int)->String
    {
        switch state[index]{
        case .Gone:
            return ""
        case .Hidden:
            return String(cardBack)
        case .Displayed:
            return String(emojis[index])
        }
    }
    
}