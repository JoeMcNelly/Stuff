//
//  Item.m
//  Exam3
//
//  Created by CSSE Department on 7/26/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

#import "Item.h"
#import "Store.h"

@implementation Item

@dynamic name;
@dynamic quantity;
@dynamic store;

@end
