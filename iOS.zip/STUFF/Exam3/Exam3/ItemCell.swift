//
//  ItemCell.swift
//  Exam3
//
//  Created by CSSE Department on 7/26/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

import UIKit

class ItemCell: UITableViewCell {

    //var callback : (item : Item)-> Void
    
    @IBAction func increment(sender: AnyObject) {
       
    }
    @IBAction func decrement(sender: AnyObject) {
        
    }
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var quantity: UILabel!
    
    
    func configureCellForInc(item : Item, callback: (Item) -> Void) {
        self.name.text=item.name
        self.quantity.text = String(stringInterpolationSegment: item.quantity)
        //self.callback = callback
        
        
        
    }


    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
