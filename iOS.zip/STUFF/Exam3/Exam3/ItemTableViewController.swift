//
//  ItemTableViewController.swift
//  Exam3
//
//  Created by CSSE Department on 7/26/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

import UIKit

class ItemTableViewController: UITableViewController {


    @IBAction func addNewPressed(sender: AnyObject) {
        let alertController = UIAlertController(title: "Create a new Item", message: "", preferredStyle: .Alert)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
            println("pressed cancel")
        }
        
        let createAction = UIAlertAction(title: "Add", style: UIAlertActionStyle.Default) { (action) -> Void in
            println("added item")
            let name = alertController.textFields![0] as! UITextField
            let number = alertController.textFields![1] as! UITextField
         
            
            let newItem = NSEntityDescription.insertNewObjectForEntityForName("Item", inManagedObjectContext: self.managedObjectContext!) as! Item
            newItem.name=name.text
            newItem.quantity=number.text.toInt()
            self.items.append(newItem)
            self.store.item.insert(newItem)
            self.sortItems()
            self.savemanagedObject()
            self.tableView.reloadData()
        }
        alertController.addTextFieldWithConfigurationHandler { (textField) -> Void in
            textField.placeholder = "Item name"
        }
        alertController.addTextFieldWithConfigurationHandler { (textField) -> Void in
            textField.placeholder = "Item quantity"
        }
        alertController.addAction(cancelAction)
        alertController.addAction(createAction)
        presentViewController(alertController, animated: true, completion: nil)

    }

    var managedObjectContext: NSManagedObjectContext?
    var store : Store!
    var items = [Item]()
    
    

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.title = store?.title
        let loader = Array(store.item)
        for var i=0;i<loader.count;i++ {
            var item = loader[i] as! Item
            items.append(item)
            sortItems()
        }
        
        
        self.tableView.reloadData()
        
    }
    
    func sortItems(){
        items = sorted(items) {$0.name < $1.name}
    }

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return self.items.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("ItemCell", forIndexPath: indexPath) as! ItemCell
        var forRow = self.items[indexPath.row]
        // callback here - increment and decrement, save context, reload data
        cell.configureCellForInc(forRow, callback: { (Int) -> Void in
            //forRow.quantity = forRow.quantity + 1 as! Int
            self.savemanagedObject()
        })
        // Configure the cell...

        return cell
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return true
    }


    func savemanagedObject(){
        var error : NSError?
        managedObjectContext?.save(&error)
        if error != nil{
            println("ERRRRRRROR")
            abort()
        }
        
    }
    
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            var forRow = self.items[indexPath.row]
            managedObjectContext?.deleteObject(forRow)
            savemanagedObject()
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        }
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        var item = self.items[indexPath.row]
        showEdit(item)
    }

    func showEdit(item:Item){
        
        let ac = UIAlertController(title: "Edit item", message: item.name, preferredStyle: UIAlertControllerStyle.Alert)


    
        
        let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) { (action) -> Void in
            let nameField = ac.textFields![0] as! UITextField
            let numberField = ac.textFields![1] as! UITextField

            var index=0
            for var i=0; i < self.items.count; i++ {
                if item == self.items[i]{
                    index = i
                    break
                }
            }
            var newItem = item
            newItem.name = nameField.text
            newItem.quantity = numberField.text.toInt()
            self.items.removeAtIndex(index)
            self.items.append(newItem)
            self.sortItems()
            self.savemanagedObject()
            self.tableView.reloadData()
        }
        
        
        let delete = UIAlertAction(title: "Delete", style: UIAlertActionStyle.Destructive) { (action) -> Void in
            self.store.item.remove(item)
            for var i=0; i < self.items.count; i++ {
                if item == self.items[i]{
                    self.items.removeAtIndex(i)
                    self.store.item.remove(item)
                    self.sortItems()
                    self.savemanagedObject()
                    self.tableView.reloadData()
                    break
                }
            }

        }
        

        let cancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
            
        }
        
        ac.addTextFieldWithConfigurationHandler { (textField) -> Void in
            textField.placeholder = "Item name"
        }
        ac.addTextFieldWithConfigurationHandler { (textField) -> Void in
            textField.placeholder = "Item quantity"
        }

        
        ac.addAction(ok)
        ac.addAction(delete)
        ac.addAction(cancel)
        
        self.presentViewController(ac, animated: true, completion: nil)

    }

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

}
