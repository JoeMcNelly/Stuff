//
//  MasterViewController.swift
//  Exam3
//
//  Created by CSSE Department on 7/26/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

import UIKit
import CoreData

class MasterViewController: UITableViewController, NSFetchedResultsControllerDelegate {

    var renaming = false;
    
    var managedObjectContext: NSManagedObjectContext?
    
    func savemanagedObject(){
        var error : NSError?
        managedObjectContext?.save(&error)
        if error != nil{
            println("ERRRRRRROR")
            abort()
        }
        
    }
    func getStoreAtPath(indexPath: NSIndexPath) -> Store!{
        return fetchedResultsController.objectAtIndexPath(indexPath) as! Store
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
        
            if let indexPath = tableView.indexPathForSelectedRow(){
                let store = getStoreAtPath(indexPath)
                (segue.destinationViewController as! ItemTableViewController).store=store
                (segue.destinationViewController as! ItemTableViewController).managedObjectContext=managedObjectContext
            }
            
        
    }
    

    func showCreatedialog(){
        let alertController = UIAlertController(title: "Create a new Store", message: "", preferredStyle: .Alert)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
            println("pressed cancel")
        }
        
        let createAction = UIAlertAction(title: "Create", style: UIAlertActionStyle.Default) { (action) -> Void in
            println("pressed Create")
            let store = alertController.textFields![0] as! UITextField
            
            println("store: \(store.text)")

            let newStore = NSEntityDescription.insertNewObjectForEntityForName("Store", inManagedObjectContext: self.managedObjectContext!) as! Store
            newStore.title=store.text
            self.savemanagedObject()
        }
        alertController.addTextFieldWithConfigurationHandler { (textField) -> Void in
            textField.placeholder = "Store"
        }
        alertController.addAction(cancelAction)
        alertController.addAction(createAction)
        presentViewController(alertController, animated: true, completion: nil)
    }
    
    func showRenameButtons(store: Store){
        let alertController = UIAlertController(title: "Rename Store", message: "", preferredStyle: .Alert)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
            println("pressed cancel")
        }
        
        let createAction = UIAlertAction(title: "Rename", style: UIAlertActionStyle.Default) { (action) -> Void in
            println("renamed!")
            let storeField = alertController.textFields![0] as! UITextField
            //storeField.text = store.title
            
            store.title = storeField.text
            self.savemanagedObject()
            self.tableView.reloadData()
        }
        alertController.addTextFieldWithConfigurationHandler { (textField) -> Void in
            textField.text = store.title
        }
        alertController.addAction(cancelAction)
        alertController.addAction(createAction)
        presentViewController(alertController, animated: true, completion: nil)
    }
    
    @IBAction func optionsPressed(sender: AnyObject) {
        
        let ac = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.ActionSheet)
        
        let createStore = UIAlertAction(title: "Create a Store", style: UIAlertActionStyle.Default) { (action) -> Void in
            self.showCreatedialog()
        }

        
        let deleteStore = UIAlertAction(title: !self.tableView.editing ? "Delete a Store" : "Stop Editing", style: UIAlertActionStyle.Destructive) { (action) -> Void in
            self.tableView.setEditing(!self.tableView.editing, animated: true)
        }
        
        let showRename = UIAlertAction(title: !self.renaming ? "Show rename buttons" : "Hide rename buttons", style: UIAlertActionStyle.Default) { (action) -> Void in
            self.renaming = !self.renaming
            self.tableView.reloadData()
            
        }
        let cancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
            
        }
        
        ac.addAction(createStore)
        ac.addAction(deleteStore)
        ac.addAction(showRename)
        ac.addAction(cancel)
      
        self.presentViewController(ac, animated: true, completion: nil)


    }
    
    var fetchedResultsController: NSFetchedResultsController {
        if _fetchedResultsController != nil {
            return _fetchedResultsController!
        }
        let fetch = NSFetchRequest(entityName: "Store")
        fetch.sortDescriptors = [NSSortDescriptor(key: "title", ascending: true)]
        

        fetch.fetchBatchSize = 20

        let aFetchedResultsController = NSFetchedResultsController(fetchRequest: fetch, managedObjectContext: self.managedObjectContext!, sectionNameKeyPath: nil, cacheName: "StoreCache")
        aFetchedResultsController.delegate = self
        _fetchedResultsController = aFetchedResultsController
        
        var error: NSError? = nil
        if !_fetchedResultsController!.performFetch(&error) {
            abort()
        }
        
        return _fetchedResultsController!
    }
    var _fetchedResultsController: NSFetchedResultsController? = nil

    
    func controllerWillChangeContent(controller: NSFetchedResultsController) {
        self.tableView.beginUpdates()
    }
    
    
    func controller(controller: NSFetchedResultsController, didChangeObject anObject: AnyObject, atIndexPath indexPath: NSIndexPath?, forChangeType type: NSFetchedResultsChangeType, newIndexPath: NSIndexPath?) {
        switch type {
        case .Insert:
                tableView.insertRowsAtIndexPaths([newIndexPath!], withRowAnimation: .Fade)
        case .Delete:

                tableView.deleteRowsAtIndexPaths([indexPath!], withRowAnimation: .Fade)
                self.tableView.endEditing(true)
            
        default:
            return
        }
    }
    
    func controllerDidChangeContent(controller: NSFetchedResultsController) {
        self.tableView.endUpdates()
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return storeCount
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    var storeCount : Int{
        return fetchedResultsController.sections![0].numberOfObjects
    }
    
    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            let store = getStoreAtPath(indexPath)
            managedObjectContext?.deleteObject(store)
   
            savemanagedObject()

            
        }
    
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    
    
    
    

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell : UITableViewCell
        cell = tableView.dequeueReusableCellWithIdentifier("StoreCell", forIndexPath: indexPath) as! UITableViewCell
        // Configure the cell...
        let store = getStoreAtPath(indexPath)
        cell.textLabel?.text = store.title
        cell.detailTextLabel?.text = String(store.item.count)
        cell.accessoryType = (self.renaming ? UITableViewCellAccessoryType.DetailDisclosureButton : UITableViewCellAccessoryType.DisclosureIndicator);
    
        return cell
    }
    
    
    override func tableView(tableView: UITableView, accessoryButtonTappedForRowWithIndexPath indexPath: NSIndexPath) {
        println("Rename pressed")
        showRenameButtons(self.fetchedResultsController.objectAtIndexPath(indexPath) as! Store)

    }
    


}

