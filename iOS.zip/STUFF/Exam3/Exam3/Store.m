//
//  Store.m
//  Exam3
//
//  Created by CSSE Department on 7/26/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

#import "Store.h"
#import "Item.h"


@implementation Store

@dynamic title;
@dynamic item;

@end
