//
//  MovieQuoteDetailViewController.swift
//  MovieQuotesCoreData
//
//  Created by CSSE Department on 3/24/15.
//  Copyright (c) 2015 CSSE Department. All rights reserved.
//

import UIKit
import Firebase

class MovieQuoteDetailViewController: UIViewController {

    @IBOutlet weak var quoteLabel: UILabel!
    @IBOutlet weak var movieLabel: UILabel!
    var quoteTextField: UITextField?
    var movieTextField: UITextField?
    var movieQuote : MovieQuote?
    var firebaseRef : Firebase?
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        //TODO: Listen for changes to the quote
        
        firebaseRef?.observeEventType(.ChildChanged, withBlock: { snapshot in
            if snapshot.key == "quote"{
                self.movieQuote?.quote = snapshot.value as! String
            }else{
                self.movieQuote?.movie = snapshot.value as! String
            }
            self.updateView()

        })
        
        
        updateView()
    }
    
    func quoteChanged() {
        //TODO: Push change to Firebase
        let mq = ["quote": self.quoteTextField!.text!, "movie": self.movieTextField!.text!]
        firebaseRef?.setValue(mq)
    }
    
    func updateView() {
        quoteLabel.text = movieQuote?.quote
        movieLabel.text = movieQuote?.movie
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .Edit, target: self, action: "showEditQuoteDialog")
    }
    
    func showEditQuoteDialog() {
        let alertController = UIAlertController(title: "Edit new movie quote", message: "", preferredStyle: .Alert)
        alertController.addTextFieldWithConfigurationHandler {
            (textField) -> Void in
            textField.placeholder = "Quote"
            textField.text = self.movieQuote?.quote
            self.quoteTextField = textField
            textField.addTarget(self, action: "quoteChanged", forControlEvents: .EditingChanged)
        }
        alertController.addTextFieldWithConfigurationHandler {
            (textField) -> Void in
            textField.placeholder = "Movie Title"
            textField.text = self.movieQuote?.movie
            self.movieTextField = textField
            textField.addTarget(self, action: "quoteChanged", forControlEvents: .EditingChanged)
        }
        let cancelAction = UIAlertAction(title: "Done", style: .Cancel) {
            (_) -> Void in
            println("Done")
        }
        alertController.addAction(cancelAction)
        presentViewController(alertController, animated: true, completion: nil)
    }

}
