# FirebaseMovieQuotesiOS
This was created as a [follow along lession](https://drive.google.com/open?id=1_fz1e2SMwzEqDInIsT7SWV5pVydFp-1pTd6Iw8unvc4&authuser=0).
