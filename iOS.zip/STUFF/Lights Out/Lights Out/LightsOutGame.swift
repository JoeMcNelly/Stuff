//
//  LightsOutGame.swift
//  Lights Out
//
//  Created by CSSE Department on 6/22/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

import Foundation
class LightsOutGame : Printable{
    
    
    var lightStates : [Bool]
    var numMoves : Int
    var isGameOver : Bool
    var description : String {
        
        return "Lights: " + lightStatesString()+" Moves: \(numMoves)"
        
    }
    init(numLights: Int){
        self.lightStates = [Bool](count: numLights, repeatedValue: true)
        self.numMoves = 0
        self.isGameOver = false
        for _ in 0...100{
            var randIndex = Int(arc4random_uniform(UInt32(numLights-1)))
            flipLights(randIndex)
        }
        
    }
    func lightStatesString() -> String{
        var lightString = ""
        for light in lightStates{
            if light{
                lightString+="1"
            }else{
                lightString+="0"
            }
        }
        return lightString
    }
    func pressedLightAtIndex(index: Int) -> Bool{
        if isGameOver{
            return true
        }
        numMoves++
        flipLights(index)
        checkGameOver()
        return isGameOver
    }
    func checkGameOver(){
        if contains(lightStates, true){
            return
        }
        //else we win
        isGameOver = true
    }
    func flipLights(index: Int){
        
        lightStates[index] = lightStates[index] == false
        if index>0{
            lightStates[index-1] = lightStates[index-1] == false //flip light to left if applicable
        }
        if index<lightStates.count-1{
            lightStates[index+1] = lightStates[index+1] == false// flip light to the right if applicable
        }
        
        
    }
    
}
