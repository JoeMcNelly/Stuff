//
//  LightsOutGame.h
//  Lights Out
//
//  Created by CSSE Department on 6/30/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LightsOutGame : NSObject{
    BOOL lightStates[100];
}

@property (nonatomic) int movesTaken;
- (id) initWithNumLights:(NSInteger) numLights;
- (BOOL) pressedLightAtIndex:(NSInteger) index;
- (BOOL) isLightOnAtIndex:(NSInteger) index;
- (BOOL) checkForWin;
- (int) getNumMoves;
@end
