//
//  LightsOutGame.m
//  Lights Out
//
//  Created by CSSE Department on 6/30/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

#import "LightsOutGame.h"

@implementation LightsOutGame{
    int totalLights;
    int numMoves;
}
- (id) initWithNumLights:(NSInteger) numLights{
    self = [super init];
    numMoves=0;
    totalLights = (int)numLights;
    for (int i=0; i<numLights; i++) {
        lightStates[i] = YES;
    }
    int rand=0;
    for (int j=0; j<100; j++) {
        rand = arc4random_uniform(numLights);
        [self flipLights:rand];
    }
    return self;
}
- (BOOL) pressedLightAtIndex:(NSInteger) index{
    if ([self checkForWin]) {
        return YES;
    }
    numMoves++;
    [self flipLights:index];
    return [self checkForWin];
}
- (BOOL) isLightOnAtIndex:(NSInteger) index{
    return lightStates[index];
}
- (BOOL) checkForWin{
    for (int i = 0; i < totalLights; i++) {
        if (lightStates[i]) {
            return NO;
        }
    }
    return YES;
}

- (int) getNumMoves{
    return numMoves;
}

- (void) flipLights:(int) index{
    lightStates[index] = lightStates[index] == NO;
    if (index>0){
        lightStates[index-1] = lightStates[index-1] == NO; //flip light to left if applicable
    }
    if (index<totalLights-1){
        lightStates[index+1] = lightStates[index+1] == NO;// flip light to the right if applicable
    }
}
@end
