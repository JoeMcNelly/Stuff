//
//  ViewController.swift
//  Lights Out
//
//  Created by CSSE Department on 6/22/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func newGamePressed(sender: AnyObject) {
        game = LightsOutGame(numLights: 13)
        update()
    }
    
    @IBAction func buttonPressed(sender: AnyObject) {
        let button = sender as! UIButton
        game.pressedLightAtIndex(button.tag)
        update()
    }
    
    let onImage = UIImage(named: "light_on.png")
    let offImage = UIImage(named: "light_off.png")
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var navBar: UINavigationBar!
    
    @IBOutlet var buttons: [UIButton]!
    
    var game = LightsOutGame(numLights: 13)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        navBar.titleTextAttributes = [NSFontAttributeName: UIFont.boldSystemFontOfSize(20)]
        update()
    }

    func update(){
        if game.getNumMoves() < 2 {
            if game.getNumMoves() < 1 {
                navBar.topItem?.title = "Turn all the Lights Off!"
                label.text = "Turn all the Lights Off!"
            }else{
                navBar.topItem?.title = "\(game.getNumMoves()) Move taken"
                label.text = "\(game.getNumMoves()) Move taken"
            }
        }else{
            navBar.topItem?.title = "\(game.getNumMoves()) Moves taken"
            label.text = "\(game.getNumMoves()) Moves taken"
        }
        
        for button in buttons {
            if game.isLightOnAtIndex(button.tag){
                button.setImage(onImage, forState: .Normal)
            }else{
                button.setImage(offImage, forState: .Normal)
            }
        }
        if game.checkForWin() {
            navBar.topItem?.title = "You won in \(game.getNumMoves()) turns!"
            label.text = "You won in \(game.getNumMoves()) turns!"
        }
    }


}

