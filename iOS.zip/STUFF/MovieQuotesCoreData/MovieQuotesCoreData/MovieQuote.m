//
//  MovieQuote.m
//  MovieQuotesCoreData
//
//  Created by CSSE Department on 7/7/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

#import "MovieQuote.h"


@implementation MovieQuote

@dynamic movie;
@dynamic quote;
@dynamic lastTouchedDate;

@end
