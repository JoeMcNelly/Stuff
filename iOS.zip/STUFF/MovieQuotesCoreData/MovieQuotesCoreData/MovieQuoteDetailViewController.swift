//
//  MovieQuoteDetailViewController.swift
//  MovieQuotesCoreData
//
//  Created by CSSE Department on 7/7/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

import UIKit

class MovieQuoteDetailViewController: UIViewController {

    
    var managedObjectContext : NSManagedObjectContext?
    
    
    @IBOutlet weak var quoteLabel: UILabel!
    @IBOutlet weak var movieLabel: UILabel!
    var movieQuote : MovieQuote?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.Edit
            , target: self, action: "showEditQuoteDialog")

    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        quoteLabel.text = movieQuote?.quote
        movieLabel.text = movieQuote?.movie
        self.updateView()
    }
  
    func showEditQuoteDialog(){
        let alertController = UIAlertController(title: "Edit Movie Quote", message: "", preferredStyle: .Alert)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
            println("pressed cancel")
        }
        
        let createAction = UIAlertAction(title: "Edit Quote", style: UIAlertActionStyle.Default) { (action) -> Void in
            let quoteTextField = alertController.textFields![0] as! UITextField
            let movieTextField = alertController.textFields![1] as! UITextField

            self.movieQuote?.quote = quoteTextField.text
            self.movieQuote?.movie = movieTextField.text
            
            self.movieQuote?.lastTouchedDate = NSDate()
            var error : NSError?
            self.managedObjectContext?.save(&error)
            if error != nil{
                println("ERRRRRRROR")
                abort()
            }
            
            self.updateView()
            
        }
        alertController.addTextFieldWithConfigurationHandler { (textField) -> Void in
            textField.placeholder = "Quote"
            textField.text = self.movieQuote?.quote
        }
        alertController.addTextFieldWithConfigurationHandler { (textField) -> Void in
            textField.placeholder = "Movie Title"
            textField.text = self.movieQuote?.movie
        }
        
        
        alertController.addAction(cancelAction)
        alertController.addAction(createAction)
        presentViewController(alertController, animated: true, completion: nil)
    }
    
    func updateView(){
        quoteLabel.text = movieQuote?.quote
        movieLabel.text = movieQuote?.movie
    }
    
    

}
