//
//  MovieQuotesTableViewController.swift
//  MovieQuotesCoreData
//
//  Created by CSSE Department on 7/6/15.
//  Copyright (c) 2015 Rose-Hulman. All rights reserved.
//

import UIKit
import CoreData

class MovieQuotesTableViewController: UITableViewController, NSFetchedResultsControllerDelegate {

    var managedObjectContext : NSManagedObjectContext?
    
    let MovieQuoteCellId = "MovieQuoteCell"
    let NoMovieQuoteCellId = "NoMovieQuoteCell"
    let DhowDetailSeg = "DhowDetailSeg"
    let entity="MovieQuote"
    let names = ["Dog", "Cat", "Bird", "Elephant"]

    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.Add
            , target: self, action: "showAndQuoteDialog")
        
        self.navigationItem.leftBarButtonItem = editButtonItem()
    }


    // MARK: - Table view data source


    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return max (movieQuoteCount, 1)
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell : UITableViewCell

        if movieQuoteCount == 0{
            cell = tableView.dequeueReusableCellWithIdentifier(NoMovieQuoteCellId, forIndexPath: indexPath) as! UITableViewCell
        }else{
            
            cell = tableView.dequeueReusableCellWithIdentifier(MovieQuoteCellId, forIndexPath: indexPath) as! UITableViewCell
        // Configure the cell...
        let movieQuote = getMovieQuoteAtIndexPath(indexPath)
        cell.textLabel?.text = movieQuote.quote
        cell.detailTextLabel?.text = movieQuote.movie
        }
        return cell
    }
    
    func showAndQuoteDialog (){
        let alertController = UIAlertController(title: "Create a new Movie Quote", message: "", preferredStyle: .Alert)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
            println("pressed cancel")
        }
        
        let createAction = UIAlertAction(title: "Create Quote", style: UIAlertActionStyle.Default) { (action) -> Void in
            println("pressed Create")
            let quoteTextField = alertController.textFields![0] as! UITextField
            let movieTextField = alertController.textFields![1] as! UITextField
            println("movie: \(movieTextField.text)    quote: \(quoteTextField.text)")

            
            let newmovieQuote = NSEntityDescription.insertNewObjectForEntityForName(self.entity, inManagedObjectContext: self.managedObjectContext!) as! MovieQuote
            newmovieQuote.quote = quoteTextField.text
            newmovieQuote.movie = movieTextField.text
            newmovieQuote.lastTouchedDate = NSDate()
            self.savemanagedOnject()
   
            
        }
        alertController.addTextFieldWithConfigurationHandler { (textField) -> Void in
            textField.placeholder = "Quote"
        }
        alertController.addTextFieldWithConfigurationHandler { (textField) -> Void in
            textField.placeholder = "Movie Title"
        }
        
        
        alertController.addAction(cancelAction)
        alertController.addAction(createAction)
        presentViewController(alertController, animated: true, completion: nil)
    }
    

    func savemanagedOnject(){
        var error : NSError?
       managedObjectContext?.save(&error)
        if error != nil{
            println("ERRRRRRROR")
            abort()
        }

    }

    override func setEditing(editing: Bool, animated: Bool) {
        if movieQuoteCount == 0{
            super.setEditing(false, animated: false)}
        else{
            super.setEditing(editing, animated: true)
        }
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return movieQuoteCount > 0
    }


    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            let quoteToDel = getMovieQuoteAtIndexPath(indexPath)
            managedObjectContext?.deleteObject(quoteToDel)
            savemanagedOnject()
 
            
        }
    }
    


    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
        if segue.identifier == DhowDetailSeg {
            if let indexPath = tableView.indexPathForSelectedRow(){
                let movieQuote = getMovieQuoteAtIndexPath(indexPath)
                (segue.destinationViewController as! MovieQuoteDetailViewController).movieQuote=movieQuote
                
                (segue.destinationViewController as! MovieQuoteDetailViewController).managedObjectContext=managedObjectContext
            }
            
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }

    
    
    var movieQuoteCount : Int{
        return fetchedResultsController.sections![0].numberOfObjects
    }
    
    func getMovieQuoteAtIndexPath(indexPath: NSIndexPath) -> MovieQuote!{
        return fetchedResultsController.objectAtIndexPath(indexPath) as! MovieQuote
    }

    
    // MARK: - Fetched results controller
    
    var fetchedResultsController: NSFetchedResultsController {
        if _fetchedResultsController != nil {
            return _fetchedResultsController!
        }
        let fetch = NSFetchRequest(entityName: entity)
        fetch.sortDescriptors = [NSSortDescriptor(key: "lastTouchedDate", ascending: false)]
      fetch.fetchBatchSize = 20

        let aFetchedResultsController = NSFetchedResultsController(fetchRequest: fetch, managedObjectContext: self.managedObjectContext!, sectionNameKeyPath: nil, cacheName: "MovieQuoteCache")
        aFetchedResultsController.delegate = self
        _fetchedResultsController = aFetchedResultsController
        
        var error: NSError? = nil
        if !_fetchedResultsController!.performFetch(&error) {

            abort()
        }
        
        return _fetchedResultsController!
    }
    var _fetchedResultsController: NSFetchedResultsController? = nil
    

    
    func controllerWillChangeContent(controller: NSFetchedResultsController) {
        self.tableView.beginUpdates()
    }

    
    func controller(controller: NSFetchedResultsController, didChangeObject anObject: AnyObject, atIndexPath indexPath: NSIndexPath?, forChangeType type: NSFetchedResultsChangeType, newIndexPath: NSIndexPath?) {
        switch type {
        case .Insert:
            if self.movieQuoteCount == 1{
                self.tableView.reloadData()
            }else{
              tableView.insertRowsAtIndexPaths([newIndexPath!], withRowAnimation: .Fade)
            }

            
        case .Delete:
            
            if movieQuoteCount == 0{
                tableView.reloadData()
                setEditing(false, animated: true)
            }else{
                tableView.deleteRowsAtIndexPaths([indexPath!], withRowAnimation: .Fade)
            }

            
        
        default:
            return
        }
    }
    
    func controllerDidChangeContent(controller: NSFetchedResultsController) {
        self.tableView.endUpdates()
    }
    


}
